package com.gzu;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Cookie;
import java.io.IOException;

/**
 * 处理登录逻辑。如果用户名和密码正确，在会话中设置用户信息并将其存储到cookie。
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // 简单验证
        if ("admin".equals(username) && "111".equals(password)) {
            // 在会话中设置用户信息
            HttpSession session = request.getSession();
            session.setAttribute("user", username);

            // 将用户信息存储到cookie中
            Cookie userCookie = new Cookie("user", username);
            userCookie.setMaxAge(600); // 设置cookie有效期为10分钟
            response.addCookie(userCookie);

            // 重定向到欢迎页面
            response.sendRedirect(request.getContextPath() + "/welcome.html");
        } else {
            // 登录失败，重定向回登录页面并提示错误
            response.sendRedirect(request.getContextPath() + "/login.html?error=true");
        }
    }
}


