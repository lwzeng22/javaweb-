package com.gzu;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

/**
 * 登录过滤器：检查用户是否已登录。如果未登录，则重定向到登录页面。
 */
@WebFilter("/*") // 过滤器应用于所有URL
public class LoginFilter implements Filter {

    private static final Set<String> EXCLUDE_PATHS = new HashSet<>();

    @Override
    public void init(FilterConfig filterConfig) {
        // 添加不需要登录即可访问的路径 (如: 登录、注册、公共资源)
        EXCLUDE_PATHS.add("/login");
        EXCLUDE_PATHS.add("/login.html");
        EXCLUDE_PATHS.add("/register");
        EXCLUDE_PATHS.add("/public");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        String requestURI = httpRequest.getRequestURI();
        String contextPath = httpRequest.getContextPath();
        String path = requestURI.substring(contextPath.length());

        // 如果路径在排除列表中，允许请求继续
        if (isExcluded(path)) {
            chain.doFilter(request, response);
            return;
        }

        // 检查用户是否已登录，通过检查会话中的 "user" 属性
        HttpSession session = httpRequest.getSession(false);
        boolean loggedIn = (session != null && session.getAttribute("user") != null);

        if (loggedIn) {
            chain.doFilter(request, response); // 用户已登录，继续处理请求
        } else {
            httpResponse.sendRedirect(contextPath + "/login.html"); // 用户未登录，重定向到登录页面
        }
    }

    // 判断请求路径是否在排除列表中
    private boolean isExcluded(String path) {
        if (path.endsWith("/")) {
            path = path.substring(0, path.length() - 1);
        }
        for (String exclude : EXCLUDE_PATHS) {
            if (path.equals(exclude) || path.startsWith(exclude + "/")) {
                return true;
            }
        }
        return false;
    }
}

